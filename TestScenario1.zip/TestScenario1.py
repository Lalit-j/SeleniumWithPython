import time
import PyPDF2
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import  expected_conditions as EC


def find_Name(Search_Name, Page1_results):
  for item in Page1_results:
      if (item.text.find(Search_Name)!= -1):
        print("found " + Search_Name)
        print(item.text)
        return item.text

class TestCase1 () :

    #1. Use browser, open <google.co.in>?
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get("http://google.co.in")
    driver.implicitly_wait(5)

    #2. In Google search bar search for <safewire>?
    search = driver.find_element_by_name("q")
    search.send_keys("SafeWire")
    search.submit()

    #3. When you get search, results click on the link that says safewire.com.
    RESULTS_LOCATOR = "//div/a[@ href='https://www.safewire.com/']"
    PDF_LOCATOR="//div/a[@href='/s/SafeWire-QuickStartGuide-for-Realtorscompressed.pdf']"
    ABOUT_LOCATOR="//div/a[@href='https://www.safechain.io/about/']"
    TEAM_LOCATOR="//div[@class='image-card sqs-dynamic-text-container']"
    TEAM_MEMBER="//div[@class='image-card sqs-dynamic-text-container']/div[@class='image-subtitle-wrapper']"
    mainWindow = driver.current_window_handle
    searchText = "https://www.linkedin.com"
    LINKEDIN_LOCATOR = '//a[contains(@href,"%s")]' % searchText

    WebDriverWait(driver,10).until(EC.visibility_of_element_located((By.XPATH,RESULTS_LOCATOR)))
    driver.find_element_by_xpath(RESULTS_LOCATOR).click()

    #9. Write a program to identify how many hyperlinks that indicate <LinkedIn> present on this
    # page.
    count = len(driver.find_elements_by_xpath(LINKEDIN_LOCATOR))
    print("LINKEDIN Hyperlinks count is " + str(count))


    #4. On Safewire.com page, click on “View PDF” button, pdf will open, validate PDF, search for
    # text” SafeWire gives you peace of mind that your real estate transaction is fraudfree”, “The
    # SafeWire Advantage”.
    WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, PDF_LOCATOR)))
    driver.find_element_by_xpath(PDF_LOCATOR).click()

    #5. On Safe wire page then click on About link.
    WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.XPATH, ABOUT_LOCATOR)))
    driver.find_element_by_xpath(ABOUT_LOCATOR).click()

    #6. Team will be display.
    handles = driver.window_handles
    driver.switch_to.window(window_name = driver.window_handles[1])
    title = driver.title
    print('Title' + title)
    WebDriverWait(driver, 40).until(EC.visibility_of_element_located((By.XPATH, TEAM_LOCATOR)))
    #scroll_page_to_location('0','300')
    x_location = 0
    y_location = 500
    last_height = driver.execute_script("return document.body.scrollHeight")

    while y_location <= last_height:
        #scroll_page_to_location(str(x_location),str(y_location))
        driver.execute_script("window.scrollTo(" + str(x_location) + "," + str(y_location) + ")")
        time.sleep(5)
        x_location = y_location
        y_location += 500
    Page1_results = driver.find_elements(By.XPATH, TEAM_LOCATOR)

    #7. From this page search for Nilesh, and display his full name and designation you collected
    # from the page.
    find_Name("Nilesh",Page1_results)

    #8. Then search for Swapnil, identify who is Account Manager and display his full name and
    # designation.
    find_Name("Swapnil", Page1_results)
    find_Name("Account Manager",Page1_results)













